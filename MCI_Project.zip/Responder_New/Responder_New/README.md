# flexi_anchor
 Anchor code with flexible behaviors. Trigger a particular type of anchor using a special UWB command.  
